-- This file was automatically generated when the server was first started.
-- It defines a custom spawn point that spawns the player in Twiggy's Bar in West Point.
function SpawnPoints()
	return {
		unemployed = {
			{ worldX = 40, worldY = 22, posX = 67, posY = 201 }
		}
	}
end
